<template>
  <!-- 出口 -->
  <router-view></router-view>
</template>

<script>
export default {}
</script>

<style>
.one {
  width: 200px;
  height: 200px;
  background: pink;
}
</style>
