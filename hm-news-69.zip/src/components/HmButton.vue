<template>
  <div class="hm-button">
    <slot></slot>
  </div>
</template>

<script>
export default {}
</script>

<style>
.hm-button {
  height: 50px;
  line-height: 50px;
  background: red;
  margin: 20px;
  text-align: center;
  font-size: 20px;
  border-radius: 25px;
  color: #fff;
}
</style>
